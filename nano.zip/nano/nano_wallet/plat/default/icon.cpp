#include <nano/nano_wallet/icon.hpp>

void nano::set_application_icon (QApplication &)
{
}
