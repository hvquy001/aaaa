#pragma once

class QApplication;
namespace nano
{
void set_application_icon (QApplication &);
}
