#pragma once

#include <nano/secure/common.hpp>

namespace nano
{
boost::filesystem::path app_path ();
}
