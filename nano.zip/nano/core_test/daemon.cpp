#include <gtest/gtest.h>

TEST (daemon, fork)
{
}